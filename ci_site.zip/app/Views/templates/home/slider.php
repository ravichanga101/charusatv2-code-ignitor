<div class="gdlr-core-pbf-wrapper section " style="padding: 0px 0px 0px 0px;">
                        <div class="gdlr-core-pbf-background-wrap" style="background-color: #191919 ;"></div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-pbf-wrapper-full-no-space">
                                <div class="gdlr-core-pbf-element">
                                    <div class="gdlr-core-revolution-slider-item gdlr-core-item-pdlr gdlr-core-item-pdb "
                                        style="padding-bottom: 0px ;">
                                        <link
                                            href="https://fonts.googleapis.com/css?family=Playfair+Display:700%2C400%7COpen+Sans:600"
                                            rel="stylesheet" property="stylesheet" type="text/css" media="all">
                                        <div id="rev_slider_2_1_wrapper"
                                            class="rev_slider_wrapper fullwidthbanner-container" data-source="gallery"
                                            style="margin:0px auto;background:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
                                            <div id="rev_slider_2_1" class="rev_slider fullwidthabanner"
                                                style="display:none;" data-version="5.4.8">
                                                <ul>
                                                    <li data-index="rs-5" data-transition="fade"
                                                        data-slotamount="default" data-hideafterloop="0"
                                                        data-hideslideonmobile="off" data-easein="default"
                                                        data-easeout="default" data-masterspeed="300"
                                                        data-thumb="upload/slider-hp2-1-100x50.jpg" data-rotate="0"
                                                        data-saveperformance="off" data-title="Slide" data-param1=""
                                                        data-param2="" data-param3="" data-param4="" data-param5=""
                                                        data-param6="" data-param7="" data-param8="" data-param9=""
                                                        data-param10="" data-description=""> <img
                                                            src="upload/slider-hp2-1.jpg" alt="" title="slider-hp2-1"
                                                            width="1800" height="958" data-bgposition="center center"
                                                            data-bgfit="cover" data-bgrepeat="no-repeat"
                                                            class="rev-slidebg" data-no-retina >
                                                        <div class="tp-caption   tp-resizeme" id="slide-5-layer-1"
                                                            data-x="48" data-y="center" data-voffset="-96"
                                                            data-width="['auto']" data-height="['auto']"
                                                            data-type="text" data-responsive_offset="on"
                                                            data-frames='[{"delay":10,"speed":300,"frame":"0","from":"x:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 5; white-space: nowrap; font-size: 33px; line-height: 33px; font-weight: 300; color: #ffffff; letter-spacing: 0px;font-family:Poppins;">
                                                            The Best University Of The State</div>
                                                        <div class="tp-caption   tp-resizeme" id="slide-5-layer-2"
                                                            data-x="45" data-y="center" data-voffset="-17"
                                                            data-width="['auto']" data-height="['auto']"
                                                            data-type="text" data-responsive_offset="on"
                                                            data-frames='[{"delay":360,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 6; white-space: nowrap; font-size: 88px; line-height: 88px; font-weight: 700; color: #ffffff; letter-spacing: 0px;font-family:Playfair Display;">
                                                            CHARUSAT</div>
                                                        <div class="tp-caption rev-btn rev-hiddenicon "
                                                            id="slide-5-layer-6" data-x="46" data-y="center"
                                                            data-voffset="97" data-width="['auto']"
                                                            data-height="['auto']" data-type="button"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":660,"speed":300,"frame":"0","from":"x:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(0,0,0,1);bg:rgba(255,255,255,1);bw:0 0 0 5px;"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[19,19,19,19]"
                                                            data-paddingright="[21,21,21,21]"
                                                            data-paddingbottom="[19,19,19,19]"
                                                            data-paddingleft="[21,21,21,21]"
                                                            style="z-index: 8; white-space: nowrap; font-size: 17px; line-height: 16px; font-weight: 600; color: #2d2d2d; letter-spacing: 0px;font-family:Poppins;background-color:rgb(255,255,255);border-color:rgb(61,177,102);border-style:solid;border-width:0px 0px 0px 5px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">
                                                            Take A Tour</div>
                                                        <!-- </li>
                                                    <li data-index="rs-6" data-transition="fade"
                                                        data-slotamount="default" data-hideafterloop="0"
                                                        data-hideslideonmobile="off" data-easein="default"
                                                        data-easeout="default" data-masterspeed="300"
                                                        data-thumb="upload/slider-hp2-2-100x50.jpg" data-rotate="0"
                                                        data-saveperformance="off" data-title="Slide" data-param1=""
                                                        data-param2="" data-param3="" data-param4="" data-param5=""
                                                        data-param6="" data-param7="" data-param8="" data-param9=""
                                                        data-param10="" data-description=""> <img
                                                            src="upload/slider-hp2-2.jpg" alt="" title="slider-hp2-2"
                                                            width="1800" height="958" data-bgposition="center center"
                                                            data-bgfit="cover" data-bgrepeat="no-repeat"
                                                            class="rev-slidebg" data-no-retina>
                                                        <div class="tp-caption   tp-resizeme" id="slide-6-layer-1"
                                                            data-x="536" data-y="center" data-voffset="-114"
                                                            data-width="['auto']" data-height="['auto']"
                                                            data-type="text" data-responsive_offset="on"
                                                            data-frames='[{"delay":10,"speed":300,"frame":"0","from":"x:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 5; white-space: nowrap; font-size: 33px; line-height: 33px; font-weight: 300; color: #ffffff; letter-spacing: 0px;font-family:Poppins;">
                                                            Be apart of our history</div>
                                                        <div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme"
                                                            id="slide-6-layer-8" data-x="537" data-y="center"
                                                            data-voffset="-10" data-width="['754']"
                                                            data-height="['121']" data-type="shape"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":350,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 6;background-color:rgba(61,177,102,0.87);">
                                                        </div>
                                                        <div class="tp-caption   tp-resizeme" id="slide-6-layer-2"
                                                            data-x="563" data-y="center" data-voffset="-15"
                                                            data-width="['auto']" data-height="['auto']"
                                                            data-type="text" data-responsive_offset="on"
                                                            data-frames='[{"delay":580,"speed":300,"frame":"0","from":"x:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 7; white-space: nowrap; font-size: 80px; line-height: 80px; font-weight: 700; color: #ffffff; letter-spacing: 0px;font-family:Playfair Display;">
                                                            Kingster</div>
                                                        <div class="tp-caption   tp-resizeme" id="slide-6-layer-3"
                                                            data-x="896" data-y="center" data-voffset="-15"
                                                            data-width="['auto']" data-height="['auto']"
                                                            data-type="text" data-responsive_offset="on"
                                                            data-frames='[{"delay":690,"speed":300,"frame":"0","from":"x:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 8; white-space: nowrap; font-size: 80px; line-height: 80px; font-weight: 400; color: #ffffff; letter-spacing: 0px;font-family:Playfair Display;">
                                                            University</div>
                                                        <div class="tp-caption   tp-resizeme" id="slide-6-layer-9"
                                                            data-x="538" data-y="center" data-voffset="129"
                                                            data-width="['746']" data-height="['auto']" data-type="text"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":980,"speed":300,"frame":"0","from":"x:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 9; min-width: 746px; max-width: 746px; white-space: normal; font-size: 19px; line-height: 31px; font-weight: 600; color: #ffffff; letter-spacing: 0px;font-family:Open Sans;">
                                                            Kingster University was established by John Smith in 1920
                                                            for the public benefit and it is recognized globally.
                                                            Throughout our great history, Kingster has offered access to
                                                            a wide range of academic opportunities.</div>
                                                        <div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme"
                                                            id="slide-6-layer-10" data-x="539" data-y="center"
                                                            data-voffset="201" data-width="['285']" data-height="['6']"
                                                            data-type="shape" data-responsive_offset="on"
                                                            data-frames='[{"delay":1290,"speed":300,"frame":"0","from":"x:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 10;background-color:rgb(61,177,102);"></div>
                                                    </li>
                                                    <li data-index="rs-7" data-transition="fade"
                                                        data-slotamount="default" data-hideafterloop="0"
                                                        data-hideslideonmobile="off" data-easein="default"
                                                        data-easeout="default" data-masterspeed="300"
                                                        data-thumb="upload/slider-hp2-3-100x50.jpg" data-rotate="0"
                                                        data-saveperformance="off" data-title="Slide" data-param1=""
                                                        data-param2="" data-param3="" data-param4="" data-param5=""
                                                        data-param6="" data-param7="" data-param8="" data-param9=""
                                                        data-param10="" data-description=""> <img
                                                            src="upload/slider-hp2-3.jpg" alt="" title="slider-hp2-3"
                                                            width="1800" height="916" data-bgposition="center center"
                                                            data-bgfit="cover" data-bgrepeat="no-repeat"
                                                            class="rev-slidebg" data-no-retina>
                                                        <div class="tp-caption   tp-resizeme" id="slide-7-layer-1"
                                                            data-x="center" data-hoffset="" data-y="center"
                                                            data-voffset="-120" data-width="['auto']"
                                                            data-height="['auto']" data-type="text"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":10,"speed":300,"frame":"0","from":"x:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 5; white-space: nowrap; font-size: 35px; line-height: 33px; font-weight: 600; color: #ffffff; letter-spacing: 0px;font-family:Poppins;">
                                                            Join the champion</div>
                                                        <div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme"
                                                            id="slide-7-layer-8" data-x="center" data-hoffset=""
                                                            data-y="center" data-voffset="-14" data-width="['347']"
                                                            data-height="['112']" data-type="shape"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":10,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 6;background-color:rgba(61,177,102,0.87);">
                                                        </div>
                                                        <div class="tp-caption   tp-resizeme" id="slide-7-layer-2"
                                                            data-x="center" data-hoffset="" data-y="center"
                                                            data-voffset="-20" data-width="['auto']"
                                                            data-height="['auto']" data-type="text"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":360,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 7; white-space: nowrap; font-size: 90px; line-height: 90px; font-weight: 700; color: #ffffff; letter-spacing: 0px;font-family:Playfair Display;">
                                                            Tiger Kings</div>
                                                        <div class="tp-caption rev-btn " id="slide-7-layer-12"
                                                            data-x="center" data-hoffset="" data-y="center"
                                                            data-voffset="113" data-width="['auto']"
                                                            data-height="['auto']" data-type="button"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":0,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgb(61,177,102);bg:rgba(255,255,255,1);bs:solid;bw:0 0 0 0;"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[21,21,21,21]"
                                                            data-paddingright="[28,28,28,28]"
                                                            data-paddingbottom="[21,21,21,21]"
                                                            data-paddingleft="[28,28,28,28]"
                                                            style="z-index: 8; white-space: nowrap; font-size: 16px; line-height: 17px; font-weight: 700; color: #2d2d2d; letter-spacing: 0px;font-family:Poppins;background-color:rgb(255,255,255);border-color:rgba(0,0,0,1);outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">
                                                            Join The Team</div>
                                                    </li>
                                                    <li data-index="rs-8" data-transition="fade"
                                                        data-slotamount="default" data-hideafterloop="0"
                                                        data-hideslideonmobile="off" data-easein="default"
                                                        data-easeout="default" data-masterspeed="300"
                                                        data-thumb="upload/slider-hp2-4-100x50.jpg" data-rotate="0"
                                                        data-saveperformance="off" data-title="Slide" data-param1=""
                                                        data-param2="" data-param3="" data-param4="" data-param5=""
                                                        data-param6="" data-param7="" data-param8="" data-param9=""
                                                        data-param10="" data-description=""> <img
                                                            src="upload/slider-hp2-4.jpg" alt="" title="slider-hp2-4"
                                                            width="1800" height="958" data-bgposition="center center"
                                                            data-bgfit="cover" data-bgrepeat="no-repeat"
                                                            class="rev-slidebg" data-no-retina>
                                                        <div class="tp-caption   tp-resizeme" id="slide-8-layer-1"
                                                            data-x="center" data-hoffset="" data-y="center"
                                                            data-voffset="106" data-width="['auto']"
                                                            data-height="['auto']" data-type="text"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":10,"speed":300,"frame":"0","from":"x:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 5; white-space: nowrap; font-size: 32px; line-height: 33px; font-weight: 300; color: #ffffff; letter-spacing: 0px;font-family:Poppins;">
                                                            Great Quality Social Life</div>
                                                        <div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme"
                                                            id="slide-8-layer-8" data-x="center" data-hoffset=""
                                                            data-y="center" data-voffset="-2" data-width="['588']"
                                                            data-height="['114']" data-type="shape"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":10,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 6;background-color:rgba(61,177,102,0.87);">
                                                        </div>
                                                        <div class="tp-caption   tp-resizeme" id="slide-8-layer-2"
                                                            data-x="center" data-hoffset="-184" data-y="center"
                                                            data-voffset="-10" data-width="['auto']"
                                                            data-height="['auto']" data-type="text"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":360,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 7; white-space: nowrap; font-size: 80px; line-height: 80px; font-weight: 700; color: #ffffff; letter-spacing: 0px;font-family:Playfair Display;">
                                                            Kingster</div>
                                                        <div class="tp-caption   tp-resizeme" id="slide-8-layer-14"
                                                            data-x="center" data-hoffset="171" data-y="center"
                                                            data-voffset="-9" data-width="['auto']"
                                                            data-height="['auto']" data-type="text"
                                                            data-responsive_offset="on"
                                                            data-frames='[{"delay":360,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                                            data-textAlign="['inherit','inherit','inherit','inherit']"
                                                            data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
                                                            data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
                                                            style="z-index: 8; white-space: nowrap; font-size: 80px; line-height: 80px; font-weight: 400; color: #ffffff; letter-spacing: 0px;font-family:Playfair Display;">
                                                            University</div>
                                                    </li> -->
                                                </ul>
                                                <div class="tp-bannertimer tp-bottom"
                                                    style="visibility: hidden !important;"></div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>